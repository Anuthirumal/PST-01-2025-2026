 class Increment {
    public static void main(String args[]) {
        int a = 5;
        a++;
        System.out.println(a);
    }
}
