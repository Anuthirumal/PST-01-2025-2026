 class EvenOdd {
    public static void main(String[] args) {

        int num = 7;   

        if (num % 2 == 0) {
            System.out.println("Even number");
        } else {
            System.out.println("Odd number");
        }
    }
}
