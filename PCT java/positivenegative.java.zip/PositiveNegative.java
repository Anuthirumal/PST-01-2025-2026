 class PositiveNegative {
    public static void main(String[] args) {

        int num = -5;    

        if (num > 0) {
            System.out.println("Positive number");
        } else if (num < 0) {
            System.out.println("Negative number");
        } else {
            System.out.println("Zero");
        }
    } 
}
