class GreaterThan100 {
    public static void main(String[] args) {

        int num = 150;    

        if (num > 100) {
            System.out.println("Given number is greater than 100");
        } else {
            System.out.println("Given number is not greater than 100");
        }
    }
}