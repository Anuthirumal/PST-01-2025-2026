public class GradeCheck {
    public static void main(String[] args) {

        int mark = 75;

        if (mark >= 90) {
            System.out.println("Grade A");
        } else if (mark >= 75) {
            System.out.println("Grade B");
        } else if (mark >= 50) {
            System.out.println("Grade C");
        } else {
            System.out.println("Fail");
        }
    }
}
