class LessEqual {
    public static void main(String args[]) {
        int a = 4, b = 6;
        System.out.println(a <= b);
    }
}
