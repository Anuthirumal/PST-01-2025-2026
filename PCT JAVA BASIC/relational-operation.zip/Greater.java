class Greater {
    public static void main(String args[]) {
        int a = 10, b = 5;
        System.out.println(a > b);
    }
}