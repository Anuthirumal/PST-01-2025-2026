 
public class equal
{
	public static void main(String[] args) {
	    int a = 5, b = 5;
        System.out.println(a == b);
		;
	}
}
