class Smaller {
    public static void main(String args[]) {
        int a = 3, b = 7;
        System.out.println(a < b);
    }
}
