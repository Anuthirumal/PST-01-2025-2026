class VoteCheck {
    public static void main(String args[]) {
        int age = 16;

        if (!(age >= 18))
            System.out.println("Not Eligible to Vote");
        else
            System.out.println("Eligible to Vote");
    }
}
