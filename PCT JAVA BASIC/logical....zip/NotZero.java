class NotZero {
    public static void main(String args[]) {
        int n = 5;

        if (!(n == 0))
            System.out.println("Not Zero");
        else
            System.out.println("Zero");
    }
}
