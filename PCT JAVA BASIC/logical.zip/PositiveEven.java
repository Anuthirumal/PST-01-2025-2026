class PositiveEven {
    public static void main(String args[]) {
        int n = 8;

        if (n > 0 && n % 2 == 0)
            System.out.println("Positive and Even");
        else
            System.out.println("Not Positive and Even");
    }
}
