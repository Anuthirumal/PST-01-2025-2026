 class AndOperator {
    public static void main(String args[]) {
        int a = 9;
        int b = 5;

        if (a > 5 && b > 3)
            System.out.println("True");
        else
            System.out.println("False");
    }
}
