  class PassCheck {
    public static void main(String args[]) {
        int mark = 38;
        int grace = 2;

        if (mark >= 40 || grace == 2)
            System.out.println("Pass");
        else
            System.out.println("Fail");
    }
}
