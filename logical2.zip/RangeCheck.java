class RangeCheck {
    public static void main(String args[]) {
        int n = 25;

        if (n > 10 && n < 50)
            System.out.println("Within range");
        else
            System.out.println("Out of range");
    }
}
